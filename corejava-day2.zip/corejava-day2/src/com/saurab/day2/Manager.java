package com.saurab.day2;

public class Manager extends Employee{
public Manager() {
System.out.println("Manager Default Constructor");
}
}
