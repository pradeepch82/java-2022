package com.saurab.day2;

public class IneheritanceDemo {
public static void main(String[] args) {
	
	Book b=new Book();
	 
	b.setId(101);
	b.setName("Let us C");
	
	System.out.println(b);
	System.out.println(b.toString());
	System.out.println("Id         :"+b.getId());
	System.out.println("Name    :"+b.getName());
	
	System.out.println(b.hashCode()+"    "+Integer.toHexString(b.hashCode()));
	System.out.println(b.getClass().getName());
	
	System.out.println("========================================");

	Employee e=null;
	
	
	Programmer p=new Programmer();
	Manager m=new Manager();
	Accountant a=new Accountant();
	
	
		
	p.setId(101);
	p.setName("Sunil");
	
	a.setId(102);
	a.setName("Mahesh");
	
	m.setId(103);
	m.setName("Rajesh");
	
	
	
	System.out.println("  Employee        : "+ e);
	e=p;
	System.out.println("  Programmner  : "+ e);
	
	((Programmer)e).show();   // down casting
	
	
	e.setName("Rajaram");
	System.out.println("  Programmner  : "+ e);
	e=a;
	System.out.println("  Accoutnat       : "+e);
	e=m;
	System.out.println("  Manager         : "+e);
		

	int i=100;
	String s="Pradeep";
	double marks=45.66;
	
	System.out.println(i);
	System.out.println(s);
	System.out.println(marks);
	
	
	
	
}
}
