package com.saurab.day2;

public class Programmer extends Employee{

	public Programmer() {
		System.out.println("Programmer Default Constructor");
       }

	public Programmer(int id, String name) {
		super(id, name);
		System.out.println("Programmer Param cosntructor...");
	}

	@Override
	public String toString() {
		return "Programmer [getId()=" + getId() + ", getName()=" + getName() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
	public void show() {
		System.out.println("Programmer Details");
		System.out.println("Id       :"+getId());
		System.out.println("Name  :"+getName());
		
	}
	
}
