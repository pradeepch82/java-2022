package com.saurab.day2;

public class Accountant extends Employee{
public Accountant() {
System.out.println("Accountant Default Constructor");
}
}
