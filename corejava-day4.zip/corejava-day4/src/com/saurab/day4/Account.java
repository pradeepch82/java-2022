package com.saurab.day4;

import java.util.Date;
 
 
 
 
 
 
 
 
 
  



public class Account  implements Comparable<Account> {
	private int accno;
	private String name;
	private double balance;
	private Date doc=new Date();
	
	public Account() {
	System.out.println("Account default constructor ");
	}

	public Account(int accno, String name, double balance) {
		super();
		this.accno = accno;
		this.name = name;
		this.balance = balance;
		System.out.println("Account parameterized constructor ");
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Date getDoc() {
		return doc;
	}

	public void setDoc(Date doc) {
		this.doc = doc;
	}

	@Override
	public String toString() {
		return "Account [accno=" + accno + ", name=" + name + ", balance=" + balance + ", doc=" + doc + "]";
	}

	@Override
	public int compareTo(Account o) {
		System.out.println(".......In compareTo methd......");
		//return this.accno-o.getAccno();  //It will sort on accno basis
		//return this.name.compareTo(o.getName());  //It will sort on name basis
		//return (int) ((int)this.balance-o.getBalance());
		return this.getDoc().compareTo(o.getDoc());
			
	}
	
}
