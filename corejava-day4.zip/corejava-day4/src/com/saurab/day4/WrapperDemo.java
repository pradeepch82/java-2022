package com.saurab.day4;
/*
 --------------------------------------------------------------------------------------
 primitive datatype                                              Wrapper class
 --------------------------------------------------------------------------------------
 byte                                                                   java.lang.Byte
 
 short                                                                  java.lang.Short  
 
 int                                                                      java.lang.Integer
 
 long                                                                    java.lang.Long
 
 float                                                                   java.lang.Float
 
 double                                                                java.lang.Double 
  
 char                                                                    java.lang.Character  
          
 boolean                                                               java.lang.Boolean
 ---------------------------------------------------------------------------------------
 
 Boxing               - converting premitive datatype into Object
 
  Unboxing         - converting Object into premitive datatype
   
*/

public class WrapperDemo {
	
	public static void main(String[] args) {
		
		int i=15;  //premitive
		char c='A';
		float f=45.666f;
		
		//Before Java 5
		
		Integer ii=new Integer(i);   // boxing
		Character cc=new Character(c); //boxing
		Float ff=new Float(f); //boxing

		int iii=ii.intValue();    //unboxing
		char ccc=cc.charValue();   //unboxing
		float fff=ff.floatValue();  //unboxing
	
		//After Java 5
		
        Integer number=3000;  //autoboxing
         int x=number;   //auto unboxing
		
		
		
		
		
		
		
		
	}

}
