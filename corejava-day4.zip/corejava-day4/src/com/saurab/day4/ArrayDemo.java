package com.saurab.day4;

import java.util.Arrays;

public class ArrayDemo {
public static void main(String[] args) {
	
	String []cities= {"PUNE","MUMBAI","CHENNAI","DELHI","BANGLORE"};
	Integer []numbers= {43534,4353,3232,34556,34554};
	
	
	Account []accounts= { new Account(34564,"SACHIN TENDULKAR",5673434.44),
			new Account(43234,"MAHESH PATIL",46733334.44),
			new Account(45645,"SUMIT PATIL",53452245.44),
			new Account(87456,"SUNIL GAWASKAR",3673334.44),
			new Account(43221,"AMIT KHANNA",967354.44),
			   };
	
	
	System.out.println("Before sorting  :"+cities);
	System.out.println("Before sorting  :"+Arrays.toString(cities));
	System.out.println("Before sorting  :"+Arrays.toString(accounts));
	System.out.println("Before sorting  :"+Arrays.toString(numbers));
	
	
	System.out.println("=========Account Details===============");
	System.out.println("=======================================");
	for(Account account:accounts)
		System.out.println(account);
	
	Arrays.sort(cities);
	Arrays.sort(numbers);
	Arrays.sort(accounts); //interally it calls compareto method of Account class
	System.out.println("============After sorting=============");	
	System.out.println("After sorting  :"+Arrays.toString(cities));
	System.out.println("After sorting  :"+Arrays.toString(numbers));
	System.out.println("=========Account Details===============");
	System.out.println("=======================================");
	for(Account account:accounts)
		System.out.println(account);
	
	
	
	
	
	
	
	
	
	
}
}
