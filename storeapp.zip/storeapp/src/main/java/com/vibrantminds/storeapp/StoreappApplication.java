package com.vibrantminds.storeapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.vibrantminds.storeapp.dao.ProductRepository;
import com.vibrantminds.storeapp.domain.Product;

@SpringBootApplication
public class StoreappApplication implements CommandLineRunner {

	
	@Autowired
	private ProductRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(StoreappApplication.class, args);
	}	

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		repository.save(new Product(null,"P1",12345.666,"E1","C1"));
		repository.save(new Product(null,"P2",12345.666,"E2","C2"));
		repository.save(new Product(null,"P3",12345.666,"E3","C3"));
		repository.save(new Product(null,"P4",12345.666,"E4","C4"));
		repository.save(new Product(null,"P5",12345.666,"E5","C5"));
		repository.save(new Product(null,"P6",12345.666,"E6","C6"));
		repository.save(new Product(null,"P7",12345.666,"E7","C7"));
		
	}
	
}
