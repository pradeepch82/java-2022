package com.saurabh.oops.day1;

public class EmployeeDemo {

	public static void main(String[] args) {
		
		//Create a employee object
		Employee e=new Employee();   //by default  constructor will be executed
		Employee e1=new Employee();   //by default  constructor will be executed
		Employee e2=new Employee(105,"Sachin",45000.00);   //Parameterized constructor will be executed
		
					
		//set the employee properties
		e.setId(101);
		e.setName("Pradeep");
		e.setSalary(12000.00);
		
		
		System.out.println("Employee details");
		System.out.println("Id         :"+e.getId());
		System.out.println("Name    :"+e.getName());
		System.out.println("Salary  :"+e.getSalary());
				
		
		System.out.println("Employee details");
		System.out.println("Id         :"+e1.getId());
		System.out.println("Name    :"+e1.getName());
		System.out.println("Salary  :"+e1.getSalary());
		
		System.out.println("Employee details");
		System.out.println("Id         :"+e2.getId());
		System.out.println("Name    :"+e2.getName());
		System.out.println("Salary  :"+e2.getSalary());
		
		
		System.out.println("  e hashocde :"+e.hashCode()+"     "+Integer.toHexString(e.hashCode()));
				
		System.out.println("ToString");
		System.out.println(e);
		System.out.println(e.toString());
		
		
		
		
	}

}
