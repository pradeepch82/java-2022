package com.saurab.day3;

public class Car extends   Vehicle   {

	@Override
	public void drive() {
	System.out.println("Drive Car : ..............");	
	}
}
