package com.saurab.day3;

abstract public class Instrument {
	abstract public void play();
}
