package com.saurab.day3;

public class Helicopter extends   Vehicle    implements Flyable   {

	@Override
	public void drive() {
	System.out.println("Drive Helicopter : ..............");	
	}
	
	@Override
	public void fly() {
		System.out.println("Fly Helicopter : ===========");	
		
	}
}
