package com.saurab.day3;

import java.util.Random;

public class TestVehicle {
	public static void main(String[] args) {
		
		Vehicle []vehicles=new Vehicle[10];
		
		for(int i=0;i<vehicles.length;i++)
		{
			int x=new Random().nextInt(5)+1;
			if(x==1) 
				vehicles[i]=new Car();
				
			if(x==2) vehicles[i]=new Bus();
			if(x==3) vehicles[i]=new Truck();
			if(x==4) vehicles[i]=new Helicopter();
			if(x==5) vehicles[i]=new Aeroplane();
			
			System.out.println(i+"      "+x);
			System.out.println(vehicles[i]);
			vehicles[i].drive();
			
			if(vehicles[i] instanceof Flyable)
				{
				Flyable f=(Flyable)vehicles[i];
				 f.fly();
				}
			}
			}

}
