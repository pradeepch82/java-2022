package com.saurab.day3;

public class Piano extends Instrument{
	@Override
	public void play() {
      System.out.println("Piano is playing :tin tin tin tin");		
	}
}
