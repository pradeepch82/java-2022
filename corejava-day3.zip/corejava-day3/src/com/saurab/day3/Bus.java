package com.saurab.day3;

public class Bus extends   Vehicle   {

	@Override
	public void drive() {
	System.out.println("Drive Bus : ..............");	
	}
}
