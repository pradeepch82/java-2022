package com.saurab.day3;

public class Truck extends   Vehicle   {

	@Override
	public void drive() {
	System.out.println("Drive Truck : ..............");	
	}
}
