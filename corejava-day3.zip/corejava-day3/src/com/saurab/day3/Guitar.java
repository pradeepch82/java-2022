package com.saurab.day3;

public class Guitar extends Instrument{
	@Override
	public void play() {
      System.out.println("Guitar is playing :tan tan tan tan");		
	}
}
