package com.saurab.day3;

public interface Flyable {
 void fly();  //public and abstract
}
