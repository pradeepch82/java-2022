package com.saurab.day3;

abstract public class Vehicle {
	abstract public void drive();
}
