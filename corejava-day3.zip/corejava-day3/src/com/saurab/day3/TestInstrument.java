package com.saurab.day3;

import java.util.Arrays;
import java.util.Random;

public class TestInstrument {
public static void main(String[] args) {
	
	Instrument ins=null;
	
	Piano p =new Piano();
	Guitar g=new Guitar();
	Flute f=new Flute();
	
	ins=p;
	ins.play();
	ins=g;
	ins.play();
	ins=f;
	ins.play();
	
	//create a array of 10 instruments
	Instrument []instruments=new Instrument[10];
	// 0  1  2 3 4 5 6 7 8 9  
	System.out.println(Arrays.toString(instruments));
	for(int i=0;i<10;i++)
	{
		Random r=new Random();
		int x=r.nextInt(3)+1;
		System.out.println(i+ "  -   "+x);
		if(x==1) instruments[i]=new Piano();
		if(x==2) instruments[i]=new Guitar();
		if(x==3) instruments[i]=new Flute();
	   System.out.println(instruments[i]);
	  instruments[i].play();
	}	
	
	
	
	
	
	
	
	
	
		
}
}
