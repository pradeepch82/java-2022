package com.saurab.day3;

public class Aeroplane extends   Vehicle   implements Flyable  {

	@Override
	public void drive() {
	System.out.println("Drive Aeroplane : ..............");	
	}
	
	@Override
	public void fly() {
	System.out.println("Fly  Aeroplane   ============");	
	}
}
